$(function(){
  console.log('hello world!');
});
